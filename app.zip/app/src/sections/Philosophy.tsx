import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

interface PhilosophyProps {
  className?: string;
}

const Philosophy = ({ className = '' }: PhilosophyProps) => {
  const sectionRef = useRef<HTMLElement>(null);
  const gradientPanelRef = useRef<HTMLDivElement>(null);
  const headlineRef = useRef<HTMLHeadingElement>(null);
  const subheadlineRef = useRef<HTMLParagraphElement>(null);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        },
      });

      // ENTRANCE (0-30%)
      scrollTl.fromTo(
        gradientPanelRef.current,
        { scale: 0.65, y: '40vh', opacity: 0 },
        { scale: 1, y: 0, opacity: 1, ease: 'none' },
        0
      );

      scrollTl.fromTo(
        headlineRef.current,
        { y: 22, opacity: 0 },
        { y: 0, opacity: 1, ease: 'none' },
        0.1
      );

      scrollTl.fromTo(
        subheadlineRef.current,
        { y: 12, opacity: 0 },
        { y: 0, opacity: 1, ease: 'none' },
        0.14
      );

      // SETTLE (30-70%): Hold

      // EXIT (70-100%)
      scrollTl.fromTo(
        gradientPanelRef.current,
        { scale: 1, y: 0, opacity: 1 },
        { scale: 1.05, y: '-26vh', opacity: 0, ease: 'power2.in' },
        0.7
      );

      scrollTl.fromTo(
        headlineRef.current,
        { y: 0, opacity: 1 },
        { y: -12, opacity: 0, ease: 'power2.in' },
        0.72
      );

      scrollTl.fromTo(
        subheadlineRef.current,
        { y: 0, opacity: 1 },
        { y: -8, opacity: 0, ease: 'power2.in' },
        0.74
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className={`section-pinned bg-primary-dark ${className}`}
    >
      {/* Gradient Panel */}
      <div
        ref={gradientPanelRef}
        className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-[72vw] h-[46vh] rounded-[36px] gradient-panel glow-violet flex flex-col items-center justify-center px-8"
      >
        <h2
          ref={headlineRef}
          className="text-[clamp(36px,5vw,80px)] font-bold text-white text-center mb-4"
        >
          Design is a system.
        </h2>

        <p
          ref={subheadlineRef}
          className="text-lg md:text-xl text-white/80 text-center"
        >
          Consistency creates trust. Trust creates results.
        </p>
      </div>
    </section>
  );
};

export default Philosophy;
