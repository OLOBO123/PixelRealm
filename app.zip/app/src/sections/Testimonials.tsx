import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Quote } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

interface TestimonialsProps {
  className?: string;
}

const Testimonials = ({ className = '' }: TestimonialsProps) => {
  const sectionRef = useRef<HTMLElement>(null);
  const headlineRef = useRef<HTMLHeadingElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);

  const testimonials = [
    {
      id: 1,
      quote: "PixelRealm delivered a clean, modern website that exceeded expectations. Communication was clear and the result was outstanding.",
      author: "Business Owner",
      company: "TechVentures Inc.",
      initials: "BO",
    },
    {
      id: 2,
      quote: "Professional, creative, and detail-oriented. The website looks premium and works perfectly on mobile.",
      author: "Consultant",
      company: "Strategy First",
      initials: "CS",
    },
    {
      id: 3,
      quote: "Highly recommended for anyone looking for a sleek and modern website. The attention to detail is remarkable.",
      author: "Startup Founder",
      company: "NexGen Labs",
      initials: "SF",
    },
  ];

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        headlineRef.current,
        { y: 30, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 80%',
          },
        }
      );

      const cards = cardsRef.current?.querySelectorAll('.testimonial-card');
      if (cards) {
        gsap.fromTo(
          cards,
          { y: 40, opacity: 0 },
          {
            y: 0,
            opacity: 1,
            duration: 0.6,
            stagger: 0.15,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: cardsRef.current,
              start: 'top 80%',
            },
          }
        );
      }
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className={`relative bg-primary-dark py-24 md:py-32 ${className}`}
    >
      <div className="w-full px-6 lg:px-12">
        {/* Header */}
        <div className="text-center mb-16">
          <h2
            ref={headlineRef}
            className="text-[clamp(36px,4vw,64px)] font-bold text-primary-light mb-4"
          >
            What Clients Say
          </h2>
        </div>

        {/* Testimonials Grid */}
        <div
          ref={cardsRef}
          className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8"
        >
          {testimonials.map((testimonial) => (
            <div
              key={testimonial.id}
              className="testimonial-card relative p-8 rounded-[24px] bg-[#12131A] border border-white/10 transition-all duration-500 hover:border-[#7B61FF]/30 hover:shadow-[0_0_40px_rgba(123,97,255,0.1)]"
            >
              {/* Quote Icon */}
              <div className="absolute top-6 right-6 w-10 h-10 rounded-full bg-[#7B61FF]/10 flex items-center justify-center">
                <Quote size={18} className="text-[#7B61FF]" />
              </div>

              {/* Content */}
              <p className="text-base text-secondary-light leading-relaxed mb-8">
                "{testimonial.quote}"
              </p>

              {/* Author */}
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-[#7B61FF] to-[#2EC3E5] flex items-center justify-center text-white font-semibold text-sm">
                  {testimonial.initials}
                </div>
                <div>
                  <p className="text-sm font-medium text-primary-light">
                    {testimonial.author}
                  </p>
                  <p className="text-xs text-secondary-light">
                    {testimonial.company}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
