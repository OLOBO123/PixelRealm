import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Lightbulb, Palette, Code } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

interface CapabilitiesProps {
  className?: string;
}

const Capabilities = ({ className = '' }: CapabilitiesProps) => {
  const sectionRef = useRef<HTMLElement>(null);
  const whiteCardRef = useRef<HTMLDivElement>(null);
  const cardImageRef = useRef<HTMLDivElement>(null);
  const headlineRef = useRef<HTMLHeadingElement>(null);
  const bodyRef = useRef<HTMLParagraphElement>(null);
  const iconRowRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        },
      });

      // ENTRANCE (0-30%)
      scrollTl.fromTo(
        whiteCardRef.current,
        { y: '100vh', scale: 0.96, opacity: 0 },
        { y: 0, scale: 1, opacity: 1, ease: 'none' },
        0
      );

      scrollTl.fromTo(
        cardImageRef.current,
        { x: '30vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'none' },
        0.05
      );

      scrollTl.fromTo(
        headlineRef.current,
        { y: 24, opacity: 0 },
        { y: 0, opacity: 1, ease: 'none' },
        0.08
      );

      scrollTl.fromTo(
        bodyRef.current,
        { y: 18, opacity: 0 },
        { y: 0, opacity: 1, ease: 'none' },
        0.12
      );

      scrollTl.fromTo(
        iconRowRef.current,
        { y: 16, opacity: 0 },
        { y: 0, opacity: 1, ease: 'none' },
        0.15
      );

      // SETTLE (30-70%): Hold

      // EXIT (70-100%)
      scrollTl.fromTo(
        whiteCardRef.current,
        { y: 0, scale: 1, opacity: 1 },
        { y: '-40vh', scale: 0.98, opacity: 0, ease: 'power2.in' },
        0.7
      );

      scrollTl.fromTo(
        cardImageRef.current,
        { x: 0, opacity: 1 },
        { x: '-18vw', opacity: 0, ease: 'power2.in' },
        0.7
      );

      scrollTl.fromTo(
        headlineRef.current,
        { y: 0, opacity: 1 },
        { y: -12, opacity: 0, ease: 'power2.in' },
        0.7
      );

      scrollTl.fromTo(
        iconRowRef.current,
        { y: 0, opacity: 1 },
        { y: 10, opacity: 0, ease: 'power2.in' },
        0.75
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const capabilities = [
    { icon: Lightbulb, label: 'STRATEGY' },
    { icon: Palette, label: 'DESIGN' },
    { icon: Code, label: 'ENGINEERING' },
  ];

  return (
    <section
      id="services"
      ref={sectionRef}
      className={`section-pinned bg-primary-dark ${className}`}
    >
      {/* White Card */}
      <div
        ref={whiteCardRef}
        className="absolute left-[7vw] top-[16vh] w-[86vw] h-[68vh] white-card overflow-hidden flex"
      >
        {/* Left Text Content */}
        <div className="w-[54%] h-full flex flex-col justify-center p-[6vh_4vw]">
          <h2
            ref={headlineRef}
            className="text-[clamp(32px,3.5vw,56px)] font-bold text-gray-900 mb-6"
          >
            Design that performs.
          </h2>

          <p ref={bodyRef} className="text-base text-gray-600 leading-relaxed max-w-lg mb-10">
            From brand systems to product UI, we craft experiences that are clear,
            fast, and human—built for real users and real business goals.
          </p>

          {/* Icon Row */}
          <div ref={iconRowRef} className="flex gap-6">
            {capabilities.map((item, index) => (
              <div key={index} className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#7B61FF] to-[#2EC3E5] flex items-center justify-center">
                  <item.icon size={18} className="text-white" />
                </div>
                <span className="font-mono text-xs tracking-[0.12em] text-gray-500">
                  {item.label}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Right Image */}
        <div
          ref={cardImageRef}
          className="w-[46%] h-full relative overflow-hidden"
        >
          <img
            src="/images/capabilities.jpg"
            alt="Modern workspace"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-l from-transparent to-white/10" />
        </div>
      </div>
    </section>
  );
};

export default Capabilities;
