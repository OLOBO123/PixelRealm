import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

interface ResultsProps {
  className?: string;
}

const Results = ({ className = '' }: ResultsProps) => {
  const sectionRef = useRef<HTMLElement>(null);
  const leftTextCardRef = useRef<HTMLDivElement>(null);
  const rightImageCardRef = useRef<HTMLDivElement>(null);
  const labelRef = useRef<HTMLSpanElement>(null);
  const headlineRef = useRef<HTMLHeadingElement>(null);
  const bodyRef = useRef<HTMLParagraphElement>(null);
  const ctaRef = useRef<HTMLAnchorElement>(null);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        },
      });

      // ENTRANCE (0-30%)
      scrollTl.fromTo(
        leftTextCardRef.current,
        { x: '-60vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'none' },
        0
      );

      scrollTl.fromTo(
        rightImageCardRef.current,
        { x: '60vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'none' },
        0
      );

      scrollTl.fromTo(
        labelRef.current,
        { y: 12, opacity: 0 },
        { y: 0, opacity: 1, ease: 'none' },
        0.1
      );

      scrollTl.fromTo(
        headlineRef.current,
        { y: 18, opacity: 0 },
        { y: 0, opacity: 1, ease: 'none' },
        0.15
      );

      scrollTl.fromTo(
        bodyRef.current,
        { y: 14, opacity: 0 },
        { y: 0, opacity: 1, ease: 'none' },
        0.2
      );

      scrollTl.fromTo(
        ctaRef.current,
        { y: 10, opacity: 0 },
        { y: 0, opacity: 1, ease: 'none' },
        0.25
      );

      // SETTLE (30-70%): Hold

      // EXIT (70-100%)
      scrollTl.fromTo(
        leftTextCardRef.current,
        { x: 0, y: 0, opacity: 1 },
        { x: '-20vw', y: '18vh', opacity: 0, ease: 'power2.in' },
        0.7
      );

      scrollTl.fromTo(
        rightImageCardRef.current,
        { x: 0, y: 0, opacity: 1 },
        { x: '20vw', y: '-18vh', opacity: 0, ease: 'power2.in' },
        0.7
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className={`section-pinned bg-primary-dark ${className}`}
    >
      {/* Left Text Card */}
      <div
        ref={leftTextCardRef}
        className="absolute left-[7vw] top-[16vh] w-[40vw] h-[68vh] white-card flex flex-col justify-center p-[6vh_3vw]"
      >
        <span ref={labelRef} className="label-mono block mb-6">
          IMPACT
        </span>

        <h2
          ref={headlineRef}
          className="text-[clamp(28px,3vw,48px)] font-bold text-gray-900 mb-6"
        >
          Built to convert.
        </h2>

        <p ref={bodyRef} className="text-base text-gray-600 leading-relaxed mb-8">
          We ship fast, accessible, responsive work—optimized for performance
          and designed to keep users engaged.
        </p>

        <a
          ref={ctaRef}
          href="#portfolio"
          className="inline-flex items-center gap-2 text-[#7B61FF] font-medium hover:gap-3 transition-all duration-300"
        >
          View case studies
          <ArrowRight size={18} />
        </a>
      </div>

      {/* Right Image Card */}
      <div
        ref={rightImageCardRef}
        className="absolute left-[51vw] top-[16vh] w-[42vw] h-[68vh] rounded-[34px] overflow-hidden shadow-2xl"
      >
        <img
          src="/images/results.jpg"
          alt="Team collaboration"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent" />
      </div>
    </section>
  );
};

export default Results;
