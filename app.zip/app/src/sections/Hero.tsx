import { useEffect, useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

interface HeroProps {
  className?: string;
}

const Hero = ({ className = '' }: HeroProps) => {
  const sectionRef = useRef<HTMLElement>(null);
  const textBlockRef = useRef<HTMLDivElement>(null);
  const gradientPanelRef = useRef<HTMLDivElement>(null);
  const labelRef = useRef<HTMLSpanElement>(null);
  const headlineRef = useRef<HTMLHeadingElement>(null);
  const subheadlineRef = useRef<HTMLParagraphElement>(null);
  const bodyRef = useRef<HTMLParagraphElement>(null);
  const ctaRef = useRef<HTMLDivElement>(null);

  // Auto-play entrance animation on mount
  useEffect(() => {
    const ctx = gsap.context(() => {
      const tl = gsap.timeline({ defaults: { ease: 'power3.out' } });

      // Gradient panel entrance
      tl.fromTo(
        gradientPanelRef.current,
        { x: '60vw', opacity: 0 },
        { x: 0, opacity: 1, duration: 0.9 },
        0
      );

      // Label entrance
      tl.fromTo(
        labelRef.current,
        { y: -12, opacity: 0 },
        { y: 0, opacity: 1, duration: 0.35 },
        0.2
      );

      // Headline entrance (word by word)
      if (headlineRef.current) {
        const words = headlineRef.current.querySelectorAll('.word');
        tl.fromTo(
          words,
          { y: 40, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.8, stagger: 0.06 },
          0.3
        );
      }

      // Subheadline
      tl.fromTo(
        subheadlineRef.current,
        { y: 20, opacity: 0 },
        { y: 0, opacity: 1, duration: 0.5 },
        0.6
      );

      // Body text
      tl.fromTo(
        bodyRef.current,
        { y: 18, opacity: 0 },
        { y: 0, opacity: 1, duration: 0.5 },
        0.7
      );

      // CTA buttons
      tl.fromTo(
        ctaRef.current,
        { y: 18, opacity: 0 },
        { y: 0, opacity: 1, duration: 0.5 },
        0.8
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  // Scroll-driven exit animation
  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
          onLeaveBack: () => {
            // Reset all elements to visible when scrolling back to top
            gsap.set([textBlockRef.current, gradientPanelRef.current, ctaRef.current], {
              opacity: 1,
              x: 0,
              scale: 1,
            });
          },
        },
      });

      // ENTRANCE (0-30%): Hold position (already animated in)
      // SETTLE (30-70%): Static

      // EXIT (70-100%)
      scrollTl.fromTo(
        textBlockRef.current,
        { x: 0, opacity: 1 },
        { x: '-18vw', opacity: 0, ease: 'power2.in' },
        0.7
      );

      scrollTl.fromTo(
        gradientPanelRef.current,
        { x: 0, scale: 1, opacity: 1 },
        { x: '22vw', scale: 0.92, opacity: 0, ease: 'power2.in' },
        0.7
      );

      scrollTl.fromTo(
        ctaRef.current,
        { y: 0, opacity: 1 },
        { y: -10, opacity: 0, ease: 'power2.in' },
        0.75
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const scrollToPortfolio = () => {
    const element = document.querySelector('#portfolio');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const scrollToContact = () => {
    const element = document.querySelector('#contact');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      ref={sectionRef}
      className={`section-pinned bg-primary-dark noise-overlay ${className}`}
    >
      {/* Decorative line */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div
          className="absolute w-[150%] h-px bg-gradient-to-r from-transparent via-white/10 to-transparent"
          style={{
            top: '40%',
            left: '-25%',
            transform: 'rotate(-18deg)',
          }}
        />
      </div>

      {/* Left Text Block */}
      <div
        ref={textBlockRef}
        className="absolute left-[7vw] top-[18vh] w-[42vw] z-10"
      >
        <span ref={labelRef} className="label-mono block mb-6">
          CREATIVE STUDIO
        </span>

        <h1
          ref={headlineRef}
          className="text-[clamp(44px,5.2vw,84px)] font-bold text-primary-light mb-4"
        >
          <span className="word inline-block">Pixel</span>
          <span className="word inline-block">Realm</span>
        </h1>

        <p
          ref={subheadlineRef}
          className="text-xl md:text-2xl text-secondary-light mb-6"
        >
          Where vision becomes digital reality.
        </p>

        <p ref={bodyRef} className="text-base text-secondary-light max-w-md mb-8 leading-relaxed">
          We design and build brands, websites, and products with precision—turning
          complex ideas into clean, memorable experiences.
        </p>

        <div ref={ctaRef} className="flex flex-wrap gap-4">
          <button onClick={scrollToPortfolio} className="btn-primary flex items-center gap-2">
            Explore Work
            <ArrowRight size={18} />
          </button>
          <button onClick={scrollToContact} className="btn-secondary">
            Hire Me
          </button>
        </div>
      </div>

      {/* Right Gradient Panel */}
      <div
        ref={gradientPanelRef}
        className="absolute left-[54vw] top-[12vh] w-[39vw] h-[76vh] rounded-[34px] gradient-panel glow-violet z-0"
      >
        {/* Subtle orb highlight */}
        <div className="absolute top-1/4 left-1/4 w-32 h-32 rounded-full bg-white/10 blur-3xl" />
        <div className="absolute bottom-1/3 right-1/4 w-24 h-24 rounded-full bg-cyan-400/20 blur-2xl" />
      </div>
    </section>
  );
};

export default Hero;
