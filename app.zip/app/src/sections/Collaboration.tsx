import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

interface CollaborationProps {
  className?: string;
}

const Collaboration = ({ className = '' }: CollaborationProps) => {
  const sectionRef = useRef<HTMLElement>(null);
  const rotatedCardRef = useRef<HTMLDivElement>(null);
  const dashedBorderRef = useRef<HTMLDivElement>(null);
  const captionRef = useRef<HTMLSpanElement>(null);
  const statementRef = useRef<HTMLParagraphElement>(null);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        },
      });

      // ENTRANCE (0-30%)
      scrollTl.fromTo(
        rotatedCardRef.current,
        { x: '-60vw', rotate: -26, opacity: 0 },
        { x: 0, rotate: -12, opacity: 1, ease: 'none' },
        0
      );

      scrollTl.fromTo(
        dashedBorderRef.current,
        { scale: 0.85, opacity: 0 },
        { scale: 1, opacity: 1, ease: 'none' },
        0
      );

      scrollTl.fromTo(
        captionRef.current,
        { y: -12, opacity: 0 },
        { y: 0, opacity: 1, ease: 'none' },
        0.1
      );

      scrollTl.fromTo(
        statementRef.current,
        { y: 18, opacity: 0 },
        { y: 0, opacity: 1, ease: 'none' },
        0.15
      );

      // SETTLE (30-70%): Hold

      // EXIT (70-100%) - Exit upward
      scrollTl.fromTo(
        rotatedCardRef.current,
        { y: 0, rotate: -12, opacity: 1 },
        { y: '-26vh', rotate: 0, opacity: 0, ease: 'power2.in' },
        0.7
      );

      scrollTl.fromTo(
        dashedBorderRef.current,
        { scale: 1, opacity: 1 },
        { scale: 1.06, opacity: 0, ease: 'power2.in' },
        0.7
      );

      scrollTl.fromTo(
        statementRef.current,
        { y: 0, opacity: 1 },
        { y: -10, opacity: 0, ease: 'power2.in' },
        0.72
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className={`section-pinned bg-primary-dark ${className}`}
    >
      {/* Caption */}
      <span
        ref={captionRef}
        className="absolute left-[7vw] top-[12vh] label-mono"
      >
        COLLABORATION
      </span>

      {/* Dashed Border Rectangle */}
      <div
        ref={dashedBorderRef}
        className="absolute left-[6vw] top-[18vh] w-[88vw] h-[64vh] rounded-[32px] border border-dashed border-white/20"
        style={{ transform: 'rotate(-12deg)' }}
      />

      {/* Rotated White Card */}
      <div
        ref={rotatedCardRef}
        className="absolute left-[11vw] top-[28vh] w-[78vw] h-[44vh] white-card flex items-center justify-center"
        style={{ transform: 'rotate(-12deg)' }}
      >
        <p
          ref={statementRef}
          className="text-[clamp(32px,4.5vw,72px)] font-bold text-gray-900 text-center px-8 leading-tight"
        >
          The best work happens together.
        </p>
      </div>
    </section>
  );
};

export default Collaboration;
