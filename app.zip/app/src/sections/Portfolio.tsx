import { useRef, useLayoutEffect, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ExternalLink, X } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

interface PortfolioProps {
  className?: string;
}

const Portfolio = ({ className = '' }: PortfolioProps) => {
  const sectionRef = useRef<HTMLElement>(null);
  const headlineRef = useRef<HTMLHeadingElement>(null);
  const subheadlineRef = useRef<HTMLParagraphElement>(null);
  const gridRef = useRef<HTMLDivElement>(null);
  const [selectedProject, setSelectedProject] = useState<number | null>(null);

  const projects = [
    {
      id: 1,
      title: 'Corporate Business Website',
      description: 'A modern, professional website designed for a Fortune 500 company. Features clean navigation, dynamic content sections, and seamless mobile responsiveness.',
      tech: ['React', 'TypeScript', 'Tailwind CSS', 'Node.js'],
      image: '/images/project-1.jpg',
    },
    {
      id: 2,
      title: 'Creative Portfolio Design',
      description: 'An elegant portfolio website for a digital artist. Showcases work with immersive galleries, smooth transitions, and a distinctive visual identity.',
      tech: ['Next.js', 'Framer Motion', 'GSAP', 'Sanity CMS'],
      image: '/images/project-2.jpg',
    },
    {
      id: 3,
      title: 'Service Company Landing Page',
      description: 'High-converting landing page for a SaaS company. Optimized for lead generation with clear CTAs, social proof, and compelling value propositions.',
      tech: ['Vue.js', 'Nuxt', 'Stripe', 'Firebase'],
      image: '/images/project-3.jpg',
    },
    {
      id: 4,
      title: 'Modern Brand Website',
      description: 'Luxury e-commerce experience for a high-end fashion brand. Features immersive product showcases, seamless checkout, and personalized recommendations.',
      tech: ['Shopify', 'Liquid', 'JavaScript', 'Algolia'],
      image: '/images/project-4.jpg',
    },
  ];

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      // Headline animation
      gsap.fromTo(
        headlineRef.current,
        { y: 30, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 80%',
          },
        }
      );

      gsap.fromTo(
        subheadlineRef.current,
        { y: 20, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.6,
          delay: 0.2,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 80%',
          },
        }
      );

      // Grid cards animation
      const cards = gridRef.current?.querySelectorAll('.project-card');
      if (cards) {
        gsap.fromTo(
          cards,
          { y: 40, opacity: 0 },
          {
            y: 0,
            opacity: 1,
            duration: 0.6,
            stagger: 0.1,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: gridRef.current,
              start: 'top 80%',
            },
          }
        );
      }
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      id="portfolio"
      ref={sectionRef}
      className={`relative bg-primary-dark py-24 md:py-32 ${className}`}
    >
      <div className="w-full px-6 lg:px-12">
        {/* Header */}
        <div className="text-center mb-16">
          <h2
            ref={headlineRef}
            className="text-[clamp(36px,4.5vw,72px)] font-bold text-primary-light mb-4"
          >
            Selected Work
          </h2>
          <p
            ref={subheadlineRef}
            className="text-lg text-secondary-light max-w-2xl mx-auto"
          >
            A curated collection of projects that showcase our expertise in design,
            development, and digital strategy.
          </p>
        </div>

        {/* Project Grid */}
        <div
          ref={gridRef}
          className="grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-8"
        >
          {projects.map((project) => (
            <div
              key={project.id}
              className="project-card group relative rounded-[24px] overflow-hidden bg-[#12131A] border border-white/10 cursor-pointer transition-all duration-500 hover:border-[#7B61FF]/50 hover:shadow-[0_0_40px_rgba(123,97,255,0.15)]"
              onClick={() => setSelectedProject(project.id)}
            >
              {/* Image */}
              <div className="relative aspect-video overflow-hidden">
                <img
                  src={project.image}
                  alt={project.title}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#12131A] via-transparent to-transparent opacity-60" />
              </div>

              {/* Content */}
              <div className="p-6">
                <h3 className="text-xl font-semibold text-primary-light mb-2 group-hover:text-[#7B61FF] transition-colors duration-300">
                  {project.title}
                </h3>
                <p className="text-sm text-secondary-light line-clamp-2 mb-4">
                  {project.description}
                </p>
                <div className="flex flex-wrap gap-2">
                  {project.tech.slice(0, 3).map((tech, index) => (
                    <span
                      key={index}
                      className="px-3 py-1 text-xs font-mono tracking-wider text-[#7B61FF] bg-[#7B61FF]/10 rounded-full"
                    >
                      {tech}
                    </span>
                  ))}
                </div>
              </div>

              {/* Hover Overlay */}
              <div className="absolute inset-0 bg-[#7B61FF]/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />
            </div>
          ))}
        </div>
      </div>

      {/* Project Modal */}
      {selectedProject && (
        <div
          className="fixed inset-0 z-[1001] flex items-center justify-center p-4 md:p-8"
          onClick={() => setSelectedProject(null)}
        >
          {/* Backdrop */}
          <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" />

          {/* Modal Content */}
          <div
            className="relative w-full max-w-4xl max-h-[90vh] overflow-auto bg-[#12131A] rounded-[24px] border border-white/10 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Close Button */}
            <button
              onClick={() => setSelectedProject(null)}
              className="absolute top-4 right-4 z-10 w-10 h-10 rounded-full bg-white/10 flex items-center justify-center text-white hover:bg-white/20 transition-colors duration-300"
            >
              <X size={20} />
            </button>

            {/* Project Image */}
            <div className="relative aspect-video">
              <img
                src={projects.find((p) => p.id === selectedProject)?.image}
                alt={projects.find((p) => p.id === selectedProject)?.title}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#12131A] via-transparent to-transparent" />
            </div>

            {/* Project Details */}
            <div className="p-8">
              <h3 className="text-2xl md:text-3xl font-bold text-primary-light mb-4">
                {projects.find((p) => p.id === selectedProject)?.title}
              </h3>
              <p className="text-base text-secondary-light leading-relaxed mb-6">
                {projects.find((p) => p.id === selectedProject)?.description}
              </p>
              <div className="flex flex-wrap gap-2 mb-8">
                {projects
                  .find((p) => p.id === selectedProject)
                  ?.tech.map((tech, index) => (
                    <span
                      key={index}
                      className="px-4 py-2 text-sm font-mono tracking-wider text-[#7B61FF] bg-[#7B61FF]/10 rounded-full"
                    >
                      {tech}
                    </span>
                  ))}
              </div>
              <button className="btn-primary flex items-center gap-2">
                View Live Project
                <ExternalLink size={18} />
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};

export default Portfolio;
